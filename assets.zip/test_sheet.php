<?php
$sheetUrl = 'https://script.google.com/macros/s/AKfycbxJ34ndBDxVM8BQay3cWKFm4WelOsUegh1-nPQBBFunkmw3hZDA3rFf4kITGad7DXev/exec';

$payload = json_encode([
    'full_name' => 'Test User',
    'email'     => 'test@test.com',
    'phone'     => '0501234567',
    'language'  => 'English',
    'interest'  => 'Light Motor Vehicle (LMV)'
]);

$ch = curl_init($sheetUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_TIMEOUT, 15);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlError = curl_error($ch);
curl_close($ch);

echo "<pre>";
echo "=== Google Sheets Debug ===\n\n";
echo "cURL Enabled:  " . (function_exists('curl_init') ? "✅ YES" : "❌ NO — cURL is disabled on this server") . "\n";
echo "HTTP Status:   " . ($httpCode ?: '❌ No response') . "\n";
echo "cURL Error:    " . ($curlError ?: '✅ None') . "\n";
echo "Response Body: " . ($response ?: '❌ Empty') . "\n";
echo "</pre>";
?>
